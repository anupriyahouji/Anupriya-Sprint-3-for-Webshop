﻿'use strict';

webStoreApp.controller('storeController',  function ($scope, Service, $http) {
	
	$scope.store = Service.store;
	$scope.cart = Service.cart;

	//http call for user login
	$scope.loginFunction = function(userName, password) {
		var customer = [];	
		if (userName == undefined || password == undefined) {
			alert("Please enter all the fields");
		} else {
			 $http.get('/WebshopUser/userLogin/'+userName+'/'+password).
		     success(function(data) {
		    	 if(data == 0 || data == undefined){
		    		 alert("The details which you entered are incorrect !!! Please enter the correct details.")
		    	 }else{
		    	 console.log("data::::::"+data.customerId);
		    	 alert("Logged In Successfully");
		    	    customer[0] = new customerDetails(data.customerId,data.firstName,data.lastName,data.address,data.contactNum,data.emailId)
		    	    $scope.cart.customerDetails = customer;
					$('#loggedInName').val("Welcome "+data.firstName+" "+data.lastName);
					$('#loggedInLi').show();
					$('#login').hide();
					$('#register').hide();
					window.location.replace("universal.html#/store");
		    	 }
		    });
		}
	};

	//http call for user registration
	$scope.registerUser = function(fname,lname,address,contactNumber,email,password,passwordConfirm){
		{
			if (fname == undefined || lname == undefined || address == undefined || contactNumber == undefined ||email == undefined || password == undefined || passwordConfirm == undefined) {
				alert("Please enter all the fields in proper format."); 
			}else if (password != passwordConfirm) {
				alert("Password and Confirm Password doesnot match !!! Please enter the same values."); 
			} else {
				$http.get('/WebshopUser/registerNewUser/'+fname+'/'+lname+'/'+address+'/'+contactNumber+'/'+email+'/'+password).
				success(function(data) {
					alert("Registered Successfully");
					window.location.replace("universal.html#/store");
				});
			}
		}
	};
	
	//function on-click of Checkout button to check whether user has logged in on not
	$scope.checkLoggedIn = function(){
		if($('#loggedInName').val() == ''){
			alert("You are not logged in !!! Please log in to checkout.")
		}else{
			window.location.replace("universal.html#/checkoutPage");
		}
	}
	
	//http call to save all order details in database
	$scope.orderProducts = function(userDetails,totalPrice,items){
		var products =" ";
		for(var i=0;i<items.length;i++){
			products = products+items[i].name+",";
		}
		var customerName = userDetails.firstName+" "+userDetails.lastName;
		var customerId = userDetails.customerId;
	    var shippingAddress = userDetails.address;
		var response = $http.get('/WebshopUser/placedOrderDetails/'+customerName+'/'+customerId+'/'+shippingAddress+'/'+totalPrice+'/'+products);
        response.success(function(data, status, headers, config) {
        	alert("Your order is placed successfully and your order ID is:"+data);
			$scope.cart.clearItems();
			$('#checkoutDiv').hide();
        });
        response.error(function(data, status, headers, config) {
            alert("In error block");
        });
	}		
		
	//This function is called on-click of sign-out button
	$scope.signOutFunction = function(){
		var r = confirm("Are you sure you want to sign out ?");
		if (r == true) {
			$scope.cart.clearItems();
			$scope.cart.clearCustomerDetails();
			$('#loggedInName').val("");
			$('#loggedInLi').hide();
			$('#login').show();
			$('#register').show();
			window.location.replace("universal.html#/store");
		} else {
		    return;
		}
	}
	
	//This function it gets the orders history for the logged in user
	$scope.viewOrders = function(){
		var customerId = $scope.cart.customerDetails[0].customerId;
		var allOrdersArray = [];
		var response = $http.get('/WebshopUser/getOrderDetails/'+customerId);
        response.success(function(data, status, headers, config) {
        	if(data == 0){
        		alert("Sorry !! You have not ordered anything from us, we dont have any order history for you!");
        	}else{
            	for (var i = 0; i < data.length; i++) {
 				   	var orderDetailsId = data[i].orderDetailsId;
 				   	var orderPlacedId = data[i].orderPlacedId;
 				   	var customerId = data[i].customerId;
 				   	var customerName = data[i].customerName;
 				   	var shippingAddress = data[i].shippingAddress;
 				   	var products = data[i].products;
 				   	products = products.replace(/,(?=[^,]*$)/, '')
 				   	var totalPrice = data[i].totalPrice;
 				   	allOrdersArray[i] = new orderDetails(orderDetailsId,orderPlacedId,customerId,customerName,shippingAddress,products,totalPrice);
     			}
            	 $scope.cart.orderDetailsHistory = allOrdersArray;
            	 window.location.replace("universal.html#/viewOrders");
        	}
        });
        response.error(function(data, status, headers, config) {
            alert("In error block");
        });
	}
});	
