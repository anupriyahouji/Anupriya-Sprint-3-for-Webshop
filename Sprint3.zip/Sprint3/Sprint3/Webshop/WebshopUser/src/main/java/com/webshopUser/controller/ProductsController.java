package com.webshopUser.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.webshop.service.ProductsService;
import com.webshop.modelObjects.Customer;
import com.webshop.modelObjects.OrderDetails;
import com.webshop.modelObjects.Product;;

/**
 * ProductsController
 *
 * @author ahouji (c) Jun 11, 2015, Sogeti B.V.
 */ 

@RestController
public class ProductsController {
	
    @Autowired(required = true)
	ProductsService productsService;
    
    private static final Logger logger = Logger.getLogger(UserController.class);
	   
	/**
	 * This function gets all the product list  
	 * @return productsList
	 */
	@RequestMapping(value = "/getProductList", method = RequestMethod.GET, produces = {"application/xml", "application/json" })
    @ResponseBody
	public List<Product> getProductsList() {
		
	   List<Product> productsList = new ArrayList<Product>();
	   try {
	       productsList = productsService.getProductsList();
	      } catch (Exception e) {
	         logger.error("Error: "+e);
	      }
	     
	      return productsList;

	}

	
	/**
	 * This function saves the cart details and customer details in database
	 * @param customerName
	 * @param customerId
	 * @param shippingAddress
	 * @param totalPrice
	 * @param products
	 * @return orderID
	 */
	@RequestMapping(value = "/placedOrderDetails/{customerName}/{customerId}/{shippingAddress}/{totalPrice}/{products}", method = RequestMethod.GET, produces = {"application/xml", "application/json" })
   @ResponseBody
  public Date placedOrderDetails(@PathVariable("customerName") String customerName,@PathVariable("customerId") int customerId,@PathVariable("shippingAddress") String shippingAddress,@PathVariable("totalPrice") int totalPrice,@PathVariable("products") String items) {
     
        java.util.Date date= new java.util.Date();
         try {
           OrderDetails orderDetails = new OrderDetails();
           orderDetails.setCustomerId(customerId);
           orderDetails.setCustomerName(customerName);
           orderDetails.setOrderPlacedId(date);
           orderDetails.setProducts(items);
           orderDetails.setShippingAddress(shippingAddress);
           orderDetails.setTotalPrice(totalPrice);
           productsService.placedOrderDetails(orderDetails);
        } catch (Exception e) {
           logger.error("Error: "+e);
        }
     return date;
   }
}
