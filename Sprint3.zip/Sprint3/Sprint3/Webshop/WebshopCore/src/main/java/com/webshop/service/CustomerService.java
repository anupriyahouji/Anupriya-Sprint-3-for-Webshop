package com.webshop.service;

import java.util.List;

import com.webshop.modelObjects.Customer;
import com.webshop.modelObjects.OrderDetails;

/**
 * CustomerService
 *
 * @author ahouji (c) Jun 11, 2015, Sogeti B.V.
 */ 
public interface CustomerService
{

   void customerRegistration(Customer customer) throws Exception ;

   Customer loginCustomer(String userName, String password) throws Exception;

   List<Customer> getAllCustomers() throws Exception;

   void updateCustomerDetails(Customer customer) throws Exception;

   List<OrderDetails> getOrderDetails(String customerId) throws Exception;

   List<OrderDetails> getAllOrderDetails() throws Exception;

}
