package com.webshop.modelObjects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;


/**
 * Category
 *
 * @author ahouji (c) Jun 11, 2015, Sogeti B.V.
 */ 
@Entity
@Table(name = "CATEGORY")
@SequenceGenerator(name = "categorySequence", sequenceName = "categorySequence", initialValue = 1, allocationSize = 1)
@Component(value = "category")
@Scope(value = "session")
public class Category {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "categorySequence")
	@Column(name = "CATEGORYID")
	private int categoryId;
	
	@Column(name = "CATEGORYNAME")
	private String categoryName;
	
	@Column(name = "CATEGORYDESC")
	private String categoryDescription;

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public String getCategoryDescription() {
		return categoryDescription;
	}

	public void setCategoryDescription(String categoryDescription) {
		this.categoryDescription = categoryDescription;
	}

}
