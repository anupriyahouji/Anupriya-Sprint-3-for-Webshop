'use strict';

//Route provider to navigate through pages
var webStoreApp = angular.module('WebStore', ['ngRoute', 'ngResource']);
webStoreApp.config([ '$routeProvider', function($routeProvider){
  	$routeProvider.when('/store', {
		templateUrl : 'adminHome.htm',
		controller : 'storeController'
	}).when('/manageProducts', {
		templateUrl : 'manageProducts.htm',
		controller : 'storeController'
	}).when('/manageCategories', {
		templateUrl : 'manageCategories.htm',
		controller : 'storeController'
	}).when('/existingCustomers', {
		templateUrl : 'existingCustomers.htm',
		controller : 'storeController'
	}).when('/viewOrders', {
		templateUrl : 'viewOrders.htm',
		controller : 'storeController'
	}).otherwise({
		redirectTo : '/store'
	});
} ]);

//It will return object with store and cart 
webStoreApp.factory("Service", [ '$http',
		function($http) {

			var serviceStore = new store($http);
			return {
				store : serviceStore,
			};
} ]);

function store($http) {
	var allProductsArray = [];
	var allCategoriesArray = [];
	var allCustomersArray = [];
	var allOrdersArray = [];
	
	//http call to get all products list
    $http({method : 'GET',url : 'getProductList'}).success(
    		function(data){
			  for (var i = 0; i < data.length; i++) {
				   var No = data[i].productId;
				   var name = data[i].productName;
				   var desc = data[i].productDescription;
				   var price = data[i].productPrice;
				   var catagoryId = data[i].category;
				   var catagoryName =catagoryId.categoryName;
				   allProductsArray[i] = new product(No, name, desc, price,catagoryName,catagoryId);

	}}). error(
		 function(data) {
			alert("In error block"+data);
	});
    
    this.products = allProductsArray;
	
    //http call to get all categories list
	$http({method : 'GET',url : 'getCategoriesList'}).success(
	     	function(data){
	     		for (var i = 0; i < data.length; i++) {
	 				  var categoryId = data[i].categoryId;
	 				  var categoryName = data[i].categoryName;
	 				  var categoryDescription = data[i].categoryDescription;
	 				 allCategoriesArray[i] = new category(categoryId, categoryName, categoryDescription);

	     	}}). error(
	 		function(data) {
	 			    alert("In error block"+data);
	 });
	 	
	this.categories = allCategoriesArray;
	
	//http call to get all customers list
	$http({method : 'GET',url : 'getAllCustomers'}).success(
	     	function(data){
	     		for (var i = 0; i < data.length; i++) {
	 				    var customerId = data[i].customerId;
	 				    var password = data[i].password;
	 				    var firstName = data[i].firstName;
	 				    var lastName = data[i].lastName;
	 				    var address = data[i].address;
	 				    var contactNum = data[i].contactNum;
	 				    var emailId = data[i].emailId;
	 				    allCustomersArray[i] = new customerDetails(customerId,password,firstName,lastName,address,contactNum,emailId);

	     	}}). error(
	 	   function(data) {
	 			   alert("In error block"+data);
	 });
	 	
	 this.customers = allCustomersArray;
	 	
	 //http call to get all orders list
	 var response = $http.get('getAllOrderDetails');
     response.success(function(data, status, headers, config) {
        	if(data == 0){
        		alert("Sorry we do not have any order history !!");
        	}else{
            	for (var i = 0; i < data.length; i++) {
 				   	var orderDetailsId = data[i].orderDetailsId;
 				   	var orderPlacedId = data[i].orderPlacedId;
 				   	var customerId = data[i].customerId;
 				   	var customerName = data[i].customerName;
 				   	var shippingAddress = data[i].shippingAddress;
 				   	var products = data[i].products;
 				   	products = products.replace(/,(?=[^,]*$)/, '')
 				   	var totalPrice = data[i].totalPrice;
 				   	allOrdersArray[i] = new orderDetails(orderDetailsId,orderPlacedId,customerId,customerName,shippingAddress,products,totalPrice);
     			}
        	}
     });
     response.error(function(data, status, headers, config) {
            alert("In error block");
     });
        
     this.orderDetailsHistory = allOrdersArray;

}

//For product details
function product(No, name, description, price,catagoryName,catagoryId,quantity) {
	this.No = No;
	this.name = name;
	this.description = description;
	this.price = price;
	this.categoryName = catagoryName;
	this.categoryId = catagoryId;
	this.quantity=quantity;
}

//This function is for order history details
function orderDetails(orderDetailsId,orderPlacedId,customerId,customerName,shippingAddress,products,totalPrice){
	this.orderDetailsId=orderDetailsId;
	this.orderPlacedId=orderPlacedId;
	this.customerId=customerId;
	this.customerName=customerName;
	this.shippingAddress=shippingAddress;
	this.products=products;
	this.totalPrice=totalPrice;
	
}

//This is for user details
function customerDetails(customerId,password,firstName,lastName,address,contactNum,emailId){
	this.customerId=customerId;
	this.password=password;
	this.firstName = firstName;
	this.lastName = lastName;
	this.address = address;
	this.contactNum = contactNum;
	this.emailId = emailId;
}

//This is for categories details
function category(categoryId,categoryName,categoryDescription){
	this.categoryId=categoryId;
	this.categoryName=categoryName;
	this.categoryDescription=categoryDescription;
}



