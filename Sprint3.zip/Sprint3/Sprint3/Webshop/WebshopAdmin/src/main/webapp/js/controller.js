﻿'use strict';

webStoreApp.controller('storeController',  function ($scope, Service, $http) {
	
	$scope.store = Service.store;

	//This function makes an http call and updates the product details
	$scope.updateProduct = function(productId,updatedName,updatedDescription,updatedPrice,categoryId,updatedCategoryName,categoryName,productName,productDescription,productPrice){
		if(name == undefined && description == undefined && price == undefined){
			alert("There are no changes made");
		}else{
			if(updatedName == productName && updatedDescription == productDescription && updatedPrice == productPrice){
				alert("There are no changes made");
			}else{
				if(updatedName != undefined){
					productName=updatedName;
				}
				if(updatedDescription != undefined){
					productDescription=updatedDescription;
				}
				if(updatedPrice != undefined){
					productPrice=updatedPrice;
				}
				if(updatedCategoryName != undefined){
					categoryName=updatedCategoryName;
				}
				var productDetails = {
						 "productId":productId, 
						 "productName":productName, 
						 "productDescription":productDescription, 
						 "productPrice":productPrice, 
	            };
				var response = $http.post('updateProduct',productDetails);
		        response.success(function(data, status, headers, config) {
		            alert("Updated Successfully");   
		            $('#update'+productId).hide();
		    		$('#edit'+productId).show();
		    		//For refreshing table data
		    		var allProductsArray = [];
		    	    $http({method : 'GET',url : 'getProductList'}).success(
		    	    		function(data){
		    				  for (var i = 0; i < data.length; i++) {
		    					   var No = data[i].productId;
		    					   var name = data[i].productName;
		    					   var desc = data[i].productDescription;
		    					   var price = data[i].productPrice;
		    					   var catagoryId = data[i].category;
		    					   var catagoryName = catagoryId.categoryName;
		    					   allProductsArray[i] = new product(No, name, desc, price,catagoryName,catagoryId);

		    		}}). error(
		    			 function(data) {
		    				alert("In error block"+data);
		    		});
		    	    $scope.store.products = allProductsArray;
		            window.location.replace("universal.html#/manageProducts");
		        });
		        response.error(function(data, status, headers, config) {
		            alert("In error block");
		        });
			
			}
		}
	}
	
	//This function makes the row editable on-click of Edit button in products table 
	$scope.editProduct = function(productId,updatedName,updatedDescription,updatedPrice,categoryId,updatedCategoryName,categoryName,productName,productDescription,productPrice){
		$('#productName'+productId).removeAttr("readonly"); 
		$('#productDescription'+productId).removeAttr("readonly");
		$('#productPrice'+productId).removeAttr("readonly"); 
		$('#update'+productId).show();
		$('#edit'+productId).hide();
	}
	
	//This function makes an http call for deleted the selected product
	$scope.deleteProduct = function(productId){
		var productDetails = {
				 "productId":productId
      };
		var response = $http.post('deleteProduct',productDetails);
	       response.success(function(data, status, headers, config) {
	       	  alert("Deleted Successfully");   
	        	//For refreshing table data
	    		var allProductsArray = [];
	    	    $http({method : 'GET',url : 'getProductList'}).success(
	    	    		function(data){
	    				  for (var i = 0; i < data.length; i++) {
	    					   var No = data[i].productId;
	    					   var name = data[i].productName;
	    					   var desc = data[i].productDescription;
	    					   var price = data[i].productPrice;
	    					   var catagoryId = data[i].category;
	    					   var catagoryName = catagoryId.categoryName;
	    					   allProductsArray[i] = new product(No, name, desc, price,catagoryName,catagoryId);

	    		}}). error(
	    			 function(data) {
	    				alert("In error block"+data);
	    		});
	    	    $scope.store.products = allProductsArray;
	       	  window.location.replace("universal.html#/manageProducts");
	    });
	    response.error(function(data, status, headers, config) {
	       	alert("In error block"+data);
	    });
	}
	
	//This function makes the row editable on-click of Edit button in categories table 
	$scope.editCategory = function(categoryId,updatedCategoryName,updatedCategoryDes,categoryName,categoryDescription){
		$('#categoryName'+categoryId).removeAttr("readonly"); 
		$('#categoryDescription'+categoryId).removeAttr("readonly"); 
		$('#update'+categoryId).show();
		$('#edit'+categoryId).hide();
	}
	
	//This function makes an http call and updates the category details
	$scope.updateCategory = function(categoryId,updatedCategoryName,updatedCategoryDes,categoryName,categoryDescription){
		if(updatedCategoryName == undefined && updatedCategoryDes == undefined){
			alert("There are no changes made");
		}else{
			if(updatedCategoryName != undefined){
				categoryName = updatedCategoryName;
			}
			if(updatedCategoryDes != undefined){
				categoryDescription = updatedCategoryDes;
			}
			var categoryDetails = {
					 "categoryId":categoryId, 
					 "categoryName":categoryName, 
					 "categoryDescription": categoryDescription
            };
            var response = $http.post('updateCategory',categoryDetails);
            response.success(function(data, status, headers, config) {
            	  alert("Updated Successfully");   
          		  $('#update'+categoryId).hide();
          		  $('#edit'+categoryId).show();
          		  //For refreshing table data
          		  var allCategoriesArray = [];
       	          $http({method : 'GET',url : 'getCategoriesList'}).success(
       	     		function(data){
       	     			for (var i = 0; i < data.length; i++) {
       	 				   var categoryId = data[i].categoryId;
       	 				   var categoryName = data[i].categoryName;
       	 				   var categoryDescription = data[i].categoryDescription;
       	 				  allCategoriesArray[i] = new category(categoryId, categoryName, categoryDescription);

       	     			}}). error(
       	 		    function(data) {
       	 			    alert("In error block"+data);
       	 	      });
       	          $scope.store.categories = allCategoriesArray;
            	  window.location.replace("universal.html#/manageCategories");
            });
            response.error(function(data, status, headers, config) {
            	alert("In error block");
            });
		}
	}
	
	//This fucntion makes an http call and deletes the category details
	$scope.deleteCategory = function(categoryId){
		var categoryDetails = {
				 "categoryId":categoryId 
       };
		var response = $http.post('deleteCategory',categoryDetails);
	       response.success(function(data, status, headers, config) {
	       	  alert("Deleted Successfully");   
	       	 //For refreshing table data
      		  var allCategoriesArray = [];
   	          $http({method : 'GET',url : 'getCategoriesList'}).success(
   	     		function(data){
   	     			for (var i = 0; i < data.length; i++) {
   	 				   var categoryId = data[i].categoryId;
   	 				   var categoryName = data[i].categoryName;
   	 				   var categoryDescription = data[i].categoryDescription;
   	 				  allCategoriesArray[i] = new category(categoryId, categoryName, categoryDescription);

   	     			}}). error(
   	 		    function(data) {
   	 			    alert("In error block"+data);
   	 	      });
   	          $scope.store.categories = allCategoriesArray;
	       	  window.location.replace("universal.html#/manageCategories");
	    });
	    response.error(function(data, status, headers, config) {
	       	alert("In error block"+data);
	    });
	    
	}
	
	//This displays new row under products table on-click of Add New Row button
	$scope.addNewRow = function(){
		$('#addNewRow').show();
	}
	
	//This function makes an http call and adds the product details 
	$scope.addProduct = function(categoryName,productName,productDescription,productPrice){
		if(categoryName == undefined ||productName == undefined || productDescription == undefined || productPrice == undefined){
			alert("Please enter all the fields");
		}
		else{
			var categoryId;
			var categoryDesc;
			for(var i=0;i<$scope.store.categories.length;i++){
				if($scope.store.categories[i].categoryName == categoryName){
					categoryId=$scope.store.categories[i].categoryId;
					categoryDesc=$scope.store.categories[i].categoryDescription;
				}
			}
			var category = {
					"categoryId":categoryId,
					"categoryName":categoryName,
					"categoryDescription":categoryDesc
			}
			var productDetails = {
					 "category":category, 
					 "productName":productName, 
					 "productDescription":productDescription, 
					 "productPrice":productPrice, 
					 "status":"Active"
	        };
			var response = $http.post('addNewProduct',productDetails);
	        response.success(function(data, status, headers, config) {
	            alert("Added Successfully");
	            $('#addNewRow').hide();
	            $('#newCategoryname').val(" ");
	            $('#newProductname').val(" ");
	            $('#newProductDesp').val(" ");
	            $('#newProductprice').val(" ");
	            //For refreshing table data
	    		var allProductsArray = [];
	    	    $http({method : 'GET',url : 'getProductList'}).success(
	    	    		function(data){
	    				  for (var i = 0; i < data.length; i++) {
	    					   var No = data[i].productId;
	    					   var name = data[i].productName;
	    					   var desc = data[i].productDescription;
	    					   var price = data[i].productPrice;
	    					   var catagoryId = data[i].category;
	    					   var catagoryName = catagoryId.categoryName;
	    					   allProductsArray[i] = new product(No, name, desc, price,catagoryName,catagoryId);

	    		}}). error(
	    			 function(data) {
	    				alert("In error block"+data);
	    		});
	    	    $scope.store.products = allProductsArray;
	            window.location.replace("universal.html#/manageProducts");
	        });
	        response.error(function(data, status, headers, config) {
	            alert("In error block");
	        });
		}
	
	}
	
	//This displays new row under category table on-click of Add New Row button
	$scope.addNewCategory = function(){
		$('#addNewCategory').show();
	}
	
	//This function makes an http call and adds the category details 
	$scope.addCategory = function(categoryName,categoryDescription){
		if(categoryName == undefined || categoryDescription == undefined){
			alert("Please enter all the details");
		}else{
			var newCategory = {
					 "categoryName":categoryName, 
					 "categoryDescription": categoryDescription
	       };
	       var response = $http.post('addNewCategory',newCategory);
	       response.success(function(data, status, headers, config) {
	       	  alert("Added Successfully");  
	          $('#addNewCategory').hide();
	          $('#newCategoryname').val(" ");
	          $('#newCategoryDesp').val(" ");
	       	 //For refreshing table data
	  		  var allCategoriesArray = [];
		          $http({method : 'GET',url : 'getCategoriesList'}).success(
		     		function(data){
		     			for (var i = 0; i < data.length; i++) {
		 				   var categoryId = data[i].categoryId;
		 				   var categoryName = data[i].categoryName;
		 				   var categoryDescription = data[i].categoryDescription;
		 				  allCategoriesArray[i] = new category(categoryId, categoryName, categoryDescription);

		     			}}). error(
		 		    function(data) {
		 			    alert("In error block"+data);
		 	      });
		          $scope.store.categories = allCategoriesArray;
	       	  window.location.replace("universal.html#/manageCategories");
	       });
	       response.error(function(data, status, headers, config) {
	       	alert("In error block"+data);
	       });
		}
	}
	
	//This makes the row editable on click of Edit button in Customers table
	$scope.editCustomer = function(customerId){
		$('#customerName'+customerId).removeAttr("readonly"); 
		$('#address'+customerId).removeAttr("readonly");
		$('#emailId'+customerId).removeAttr("readonly"); 
		$('#contactNum'+customerId).removeAttr("readonly"); 
		$('#update'+customerId).show();
		$('#edit'+customerId).hide();
	}
	
	//This function makes an http call and updates the customer details
	$scope.updateCustomer = function(customerDetails,updatedCustName,updatedAdd,updatedEmail,updatedContactNo){
		var address=customerDetails.address;
		var emailId=customerDetails.emailId;
		var contactNum=customerDetails.contactNum;
		var firstName=customerDetails.firstName;
		var lastName=customerDetails.lastName;
		if(updatedCustName != undefined){
			updatedCustName = updatedCustName.split(/\s+/);
			firstName=updatedCustName[0];
		    lastName=updatedCustName[1];
		}
		if(updatedAdd != undefined){
			address=updatedAdd;
		}
		if(updatedEmail != undefined){
			emailId=updatedEmail;
		}
		if(updatedContactNo != undefined){
			contactNum = updatedContactNo;
		}
		var customerDetails = {
		        "customerId" : customerDetails.customerId,
		        "firstName" : firstName,
		        "lastName" : lastName,
		        "address" : address,
		        "contactNum" : contactNum,
		        "emailId" : emailId,
		        "password":customerDetails.password
		};
		
		//This is for user details
		function customerDetailConst(customerId,password,firstName,lastName,address,contactNum,emailId){
			this.customerId=customerId;
			this.password=password;
			this.firstName = firstName;
			this.lastName = lastName;
			this.address = address;
			this.contactNum = contactNum;
			this.emailId = emailId;
		}
		var response = $http.post('updateCustomerDetails',customerDetails);
        response.success(function(data, status, headers, config) {
            alert("Updated Successfully");  
            //For refreshing table data
            var allCustomersArray = [];
    	 	$http({method : 'GET',url : 'getAllCustomers'}).success(
    	     		function(data){
    	     			for (var i = 0; i < data.length; i++) {
   	 				     var customerId = data[i].customerId;
   	 				     var password = data[i].password;
   	 				     var firstName = data[i].firstName;
   	 				     var lastName = data[i].lastName;
   	 				     var address = data[i].address;
   	 				     var contactNum = data[i].contactNum;
   	 				     var emailId = data[i].emailId;
   	 				     allCustomersArray[i] = new customerDetailConst(customerId,password,firstName,lastName,address,contactNum,emailId);

    	     		}}). error(
    	 		    function(data) {
    	 			    alert("In error block"+data);
    	 	 });
    	 	 $scope.store.customers = allCustomersArray;
             window.location.replace("universal.html#/existingCustomers");
        });
        response.error(function(data, status, headers, config) {
            alert("In error block");
        });
	}
});	
