package com.webshopAdmin.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.webshop.modelObjects.Product;
import com.webshop.service.ProductsService;

/**
 * AdminController
 *
 * @author ahouji (c) Jun 12, 2015, Sogeti B.V.
 */ 
@RestController
public class ProductController
{

   @Autowired(required = true)
   ProductsService productsService;
    
    private static final Logger logger = Logger.getLogger(ProductController.class);
      
   /**
    * This function returns all the product list  
    * @return productsList
    */
   @RequestMapping(value = "/getProductList", method = RequestMethod.GET, produces = {"application/xml", "application/json" })
   @ResponseBody
   public List<Product> getProductsList() {
      
      List<Product> productsList = new ArrayList<Product>();
      try {
          productsList = productsService.getProductsList();
      } catch (Exception e) {
            logger.error("Error: "+e);
      }
      return productsList;
   }
   
   /**
    * This method updates the product details
    * @param product
    */
   @RequestMapping(value = "/updateProduct", method = RequestMethod.POST)
   public @ResponseBody void updateProduct(@RequestBody Product product){
      try
      {
         productsService.updateProduct(product);
      }
      catch (Exception e)
      {
         logger.error("Error: "+e);
      }
   }

   /**
    * This method deletes the product details
    * @param product
    */
   @RequestMapping(value = "/deleteProduct", method = RequestMethod.POST)
   public @ResponseBody void deleteProduct(@RequestBody Product product){
      try
      {
         productsService.deleteProduct(product);
      }
      catch (Exception e)
      {
         logger.error("Error: "+e);
      }
   }
   
   /**
    * This method adds the new product details
    * @param product
    */
   @RequestMapping(value = "/addNewProduct", method = RequestMethod.POST)
   public @ResponseBody void addNewProduct(@RequestBody Product product){
      try
      {
         productsService.addNewProduct(product);
      }
      catch (Exception e)
      {
         logger.error("Error: "+e);
      }
   }   
   
}
