package com.webshopAdmin.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.webshop.modelObjects.Customer;
import com.webshop.modelObjects.OrderDetails;
import com.webshop.service.CustomerService;


/**
 * CustomerController
 *
 * @author ahouji (c) Jun 17, 2015, Sogeti B.V.
 */ 
@RestController
public class CustomerController
{

   @Autowired(required = true)
   CustomerService customersService;
    
   private static final Logger logger = Logger.getLogger(ProductController.class);
      
   /**
    * This method returns the list of all customers
    * @return customersList
    */
   @RequestMapping(value = "/getAllCustomers", method = RequestMethod.GET, produces = {"application/xml", "application/json" })
   @ResponseBody
   public List<Customer> getAllCustomers() {
      
      List<Customer> customersList = new ArrayList<Customer>();
      try {
         customersList = customersService.getAllCustomers();
      } catch (Exception e) {
            logger.error("Error: "+e);
      }
      return customersList;
   }
  
   /**
    * This method updates the details of customer
    * @param customer
    */
   @RequestMapping(value = "/updateCustomerDetails", method = RequestMethod.POST)
   public @ResponseBody void updateCustomerDetails(@RequestBody Customer customer){
      try
      {
         customersService.updateCustomerDetails(customer);
      }
      catch (Exception e)
      {
         logger.error("Error: "+e);
      }
   }
   
   /**
    * This method gets the order details of all the customers
    * @return orderDetails
    */
   @RequestMapping(value = "/getAllOrderDetails", method = RequestMethod.GET, produces = {"application/xml", "application/json" })
   @ResponseBody
   public List<OrderDetails> getAllOrderDetails() {
     
      List<OrderDetails> orderDetails = new ArrayList<OrderDetails>();
       try {
          orderDetails = customersService.getAllOrderDetails();
       } catch (Exception e) {
          logger.error("Error: "+e);
       }
       return orderDetails;
   }
}
