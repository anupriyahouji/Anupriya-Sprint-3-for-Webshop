package com.webshopAdmin.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.webshop.modelObjects.Category;
import com.webshop.service.CategoriesService;

/**
 * CategoryController
 *
 * @author ahouji (c) Jun 15, 2015, Sogeti B.V.
 */ 
@RestController
public class CategoryController
{
   @Autowired(required = true)
   CategoriesService categoriesService;
   
   private static final Logger logger = Logger.getLogger(ProductController.class);
   
   /**
    * This method returns the list of all categories
    * @return categoriesList
    */
   @RequestMapping(value = "/getCategoriesList", method = RequestMethod.GET, produces = {"application/xml", "application/json" })
   @ResponseBody
   public List<Category> getCategoriesList() {
      
     List<Category> categoriesList = new ArrayList<Category>();
     try {
        categoriesList = categoriesService.getCategoriesList();
     } catch (Exception e) {
           logger.error("Error: "+e);
     }
     return categoriesList;

   }
   
   
   /**
    * This method updates the category details
    * @param category
    */
   @RequestMapping(value = "/updateCategory", method = RequestMethod.POST)
   public @ResponseBody void updateCategory(@RequestBody Category category){
      try
      {
         categoriesService.updateCategory(category);
      }
      catch (Exception e)
      {
         logger.error("Error: "+e);
      }
   }

   /**
    * This method adds the new category details
    * @param category
    */
   @RequestMapping(value = "/addNewCategory", method = RequestMethod.POST)
   public @ResponseBody void addNewCategory(@RequestBody Category category){
      try
      {
         categoriesService.addNewCategory(category);
      }
      catch (Exception e)
      {
         logger.error("Error: "+e);
      }
   }
   
   /**
    * This method deletes the category details
    * @param category
    */
   @RequestMapping(value = "/deleteCategory", method = RequestMethod.POST)
   public @ResponseBody void deleteCategory(@RequestBody Category category){
      try
      {
         categoriesService.deleteCategory(category);
      }
      catch (Exception e)
      {
         logger.error("Error: "+e);
      }
    
   }
}
