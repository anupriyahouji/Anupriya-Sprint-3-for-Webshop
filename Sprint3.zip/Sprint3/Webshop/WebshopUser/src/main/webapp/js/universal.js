'use strict';

//Route provider to navigate through pages
var webStoreApp = angular.module('WebStore', ['ngRoute', 'ngResource']);
webStoreApp.config([ '$routeProvider', function($routeProvider){
  	$routeProvider.when('/store', {
		templateUrl : 'allProductsPage.htm',
		controller : 'storeController'
	}).when('/cart', {
		templateUrl : 'shoppingCart.htm',
		controller : 'storeController'
	}).when('/registrationPage', {
		templateUrl : 'customerRegistration.htm',
		controller : 'storeController'
	}).when('/loginPage', {
		templateUrl : 'loginPage.htm',
		controller : 'storeController'
	}).when('/checkoutPage', {
		templateUrl : 'checkoutPage.htm',
		controller : 'storeController'
	}).when('/viewOrders', {
		templateUrl : 'viewOrders.htm',
		controller : 'storeController'
	}).otherwise({
		redirectTo : '/store'
	});
} ]);

//It will return object with store and cart 
webStoreApp.factory("Service", [ '$http', '$resource',
		function($http, $resource) {

			var serviceStore = new store($http);
			var serviceCart = new cartOperations("WebStore");
			return {
				store : serviceStore,
				cart : serviceCart
			};
} ]);

//This contains all the products  
function store($http) {
	var allProductsArray = [];
	var allCategoriesArray = [];
    $http({method : 'GET',url : 'getProductList'}).success(
    		function(data){
			  for (var i = 0; i < data.length; i++) {
				   var No = data[i].productId;
				   var name = data[i].productName;
				   var desc = data[i].productDescription;
				   var price = data[i].productPrice;
				   var catagoryId = data[i].category;
				   var catagoryName = catagoryId.categoryName;
				   allProductsArray[i] = new product(No, name, desc, price,catagoryName,catagoryId);

	}}). error(
		 function(data) {
			alert("In error block"+data);
	});
    
	this.products = allProductsArray;
	
    $http({method : 'GET',url : 'getCategoriesList'}).success(
    		function(data){
    			for (var i = 0; i < data.length; i++) {
				   var categoryId = data[i].categoryId;
				   var categoryName = data[i].categoryName;
				   var categoryDescription = data[i].categoryDescription;
				  allCategoriesArray[i] = new category(categoryId, categoryName, categoryDescription);
    			}}). error(
		    function(data) {
			    alert("In error block"+data);
	 });
	this.categories = allCategoriesArray;
}

//For product details
function product(No, name, description, price,catagoryName,catagoryId,quantity) {
	this.No = No;
	this.name = name;
	this.description = description;
	this.price = price;
	this.categoryName = catagoryName;
	this.categoryId = catagoryId;
	this.quantity=quantity;
}

//For creating an array to  store items in the cart
function cartItem(No, name, price, quantity) {
	this.No = No;
	this.name = name;
	this.price = price * 1;
	this.quantity = quantity * 1;
}

//For performing all the cart operations
function cartOperations(cartProducts) {
	this.cartProducts = cartProducts;
	this.clearCart = false;
	this.items = [];
	this.loadItems();
	this.customerDetails=[];
	this.orderDetailsHistory=[];
}

//This is for categories details
function category(categoryId,categoryName,categoryDescription){
	this.categoryId=categoryId;
	this.categoryName=categoryName;
	this.categoryDescription=categoryDescription;
}

//This is for user details
function customerDetails(customerId,firstName,lastName,address,contactNum,emailId) {
	this.customerId=customerId;
	this.firstName = firstName;
	this.lastName = lastName;
	this.address = address;
	this.contactNum = contactNum;
	this.emailId = emailId;
}

//This function is for order history details
function orderDetails(orderDetailsId,orderPlacedId,customerId,customerName,shippingAddress,products,totalPrice){
	this.orderDetailsId=orderDetailsId;
	this.orderPlacedId=orderPlacedId;
	this.customerId=customerId;
	this.customerName=customerName;
	this.shippingAddress=shippingAddress;
	this.products=products;
	this.totalPrice=totalPrice;
}

// It will add the selected product along with its details to the cart
cartOperations.prototype.addItem = function(No, name, price, quantity) {
	quantity = this.toNumber(quantity);
	if (quantity != 0) {
		var alreadyExist = false;
		for (var i = 0; i < this.items.length && !alreadyExist; i++) {
			var item = this.items[i];
			if (item.No == No) {
				alreadyExist = true;
				item.quantity = this.toNumber(item.quantity + quantity);
				if (item.quantity <= 0) {
					this.items.splice(i, 1);
				}
			}
		}
		if (!alreadyExist) {
			var item = new cartItem(No, name, price, quantity);
			this.items.push(item);
		}
		this.saveItems();
	}
}

//It will add the cart products to local storage
cartOperations.prototype.saveItems = function() {
	if (localStorage != null) {
		localStorage[this.cartProducts + "index"] = JSON.stringify(this.items);
	}
}

//It will load the items from local storage and push it into any array 
cartOperations.prototype.loadItems = function() {
	var items = null;
 	if(localStorage != null){
 		items = localStorage[this.cartProducts + "index"];
 	}
 	if (items != null) {
 			var items = JSON.parse(items);
 			for (var i = 0; i < items.length; i++) {
 				var item = items[i];
 				if (item.No != null && item.name != null && item.price != null && item.quantity != null) {
 					item = new cartItem(item.No, item.name, item.price,item.quantity);
 					this.items.push(item);
 				}
 			}
 	}
 }

// It will give the total price for all products present in the cart
cartOperations.prototype.getTotalPrice = function(No) {
	var total = 0;
	for (var i = 0; i < this.items.length; i++) {
		var item = this.items[i];
		if (No == null || item.No == No) {
			total += this.toNumber(item.quantity * item.price);
		}
	}
	return total;
}

//It will give the total count of all products present in the cart
cartOperations.prototype.getTotalCount = function(No) {
	var count = 0;
	for (var i = 0; i < this.items.length; i++) {
		var item = this.items[i];
		if (No == null || item.No == No) {
			count += this.toNumber(item.quantity);
		}
	}
	return count;
}

// It will clear your shopping cart
cartOperations.prototype.clearItems = function() {
	this.items = [];
	this.saveItems();
}

//It will clear the customer details who had logged in
cartOperations.prototype.clearCustomerDetails = function() {
	this.customerDetails = [];
}

//It will return the value in number format
cartOperations.prototype.toNumber = function(value) {
	value = value * 1;
	return isNaN(value) ? 0 : value;
}


