package com.webshopUser.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.webshop.modelObjects.Category;
import com.webshop.service.CategoriesService;

/**
 * CategoriesController
 *
 * @author ahouji (c) Jun 11, 2015, Sogeti B.V.
 */ 
@RestController
public class CategoriesController
{
   @Autowired(required = true)
   CategoriesService categoriesService;
   
   private static final Logger logger = Logger.getLogger(CategoriesController.class);
   
   /**
    * This method returns the list of all categories
    * @return categoriesList
    */
   @RequestMapping(value = "/getCategoriesList", method = RequestMethod.GET, produces = {"application/xml", "application/json" })
   @ResponseBody
   public List<Category> getCategoriesList() {
      
     List<Category> categoriesList = new ArrayList<Category>();
     try {
        categoriesList = categoriesService.getCategoriesList();
        } catch (Exception e) {
           logger.error("Error: "+e);
        }
     return categoriesList;

   }

}
