package com.webshopUser.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.webshop.modelObjects.Customer;
import com.webshop.modelObjects.OrderDetails;
import com.webshop.service.CustomerService;

/**
 * UserController
 *
 * @author ahouji (c) Jun 11, 2015, Sogeti B.V.
 */ 
@RestController
public class UserController {

    @Autowired(required = true)
    CustomerService customerService;
   
    private static final Logger logger = Logger.getLogger(UserController.class);
    
	/**
	 * This function verifies user name and password and gets the user details
	 * @param userName
	 * @param password
	 * @return customer
	 */
	@RequestMapping(value = "/userLogin/{userName}/{password}", method = RequestMethod.GET, produces = {"application/xml", "application/json" })
    @ResponseBody
    public Customer userLogin(@PathVariable("userName") String userName, @PathVariable("password") String password) {
	   
		Customer customer = new Customer();
        try {
            customer = customerService.loginCustomer(userName,password);
        } catch (Exception e) {
           logger.error("Error: "+e);
        }
     
        return customer;

    }
	
	
	 /**
	 * This method registers the user entered details and creates an account
	 * @param fname
	 * @param lname
	 * @param address
	 * @param contactNumber
	 * @param email
	 * @param password
	 */
	@RequestMapping(value = "/registerNewUser/{fname}/{lname}/{address}/{contactNumber}/{email}/{password}", method = RequestMethod.GET, produces = { "application/xml", "application/json" })
	 @ResponseBody
	 public void registerNewUser(@PathVariable("fname") String fname,@PathVariable("lname") String lname,@PathVariable("address") String address,@PathVariable("contactNumber") String contactNumber,@PathVariable("email") String email,@PathVariable("password") String password) {
	      
	     Customer customer = new Customer();
	     customer.setFirstName(fname);
	     customer.setLastName(lname);
	     customer.setAddress(address);
	     customer.setContactNum(contactNumber);
	     customer.setEmailId(email);
	     customer.setPassword(password);
	     customer.setRoleId(1);
	     
	     try{
	         customerService.customerRegistration(customer);
	      }catch (Exception e) {
	         logger.error("Error: "+e);
	      }
	   }
	
	
	/**
	 * This method gets the order details for logged in customer
	 * @param customerId
	 * @return orderDetails
	 */
	@RequestMapping(value = "/getOrderDetails/{customerId}", method = RequestMethod.GET, produces = {"application/xml", "application/json" })
   @ResponseBody
   public List<OrderDetails> getOrderDetails(@PathVariable("customerId") String customerId) {
     
	   List<OrderDetails> orderDetails = new ArrayList<OrderDetails>();
       try {
          orderDetails = customerService.getOrderDetails(customerId);
       } catch (Exception e) {
          logger.error("Error: "+e);
       }
       return orderDetails;
   }
}
