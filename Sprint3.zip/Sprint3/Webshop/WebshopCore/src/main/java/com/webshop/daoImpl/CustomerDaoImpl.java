package com.webshop.daoImpl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.webshop.dao.CustomerDao;
import com.webshop.modelObjects.Customer;
import com.webshop.modelObjects.OrderDetails;
import com.webshop.modelObjects.Product;

/**
 * CustomerDaoImpl
 *
 * 
 * @author ahouji (c) Jun 11, 2015, Sogeti B.V.
 */ 
@Repository("CustomerDao")
public class CustomerDaoImpl implements CustomerDao {

	@Autowired
	SessionFactory sessionFactory;

	/**
    * This method gets the customer details on login
    * @param userName
    * @param password
    */
	public Customer loginCustomer(String userName, String password)
			throws Exception {
		Customer customer = new Customer();
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from Customer where emailId= :emailId and password= :password");
		query.setString("emailId", userName);
		query.setString("password", password);
		customer = (Customer) query.uniqueResult();
		return customer;
	}

	 /**
    * This method registers the customer details and creates an account
    * @param customer
    */
	public void customerRegistration(Customer customer) throws Exception {

		Session session = sessionFactory.openSession();
		session.beginTransaction();
		session.save(customer);
		session.getTransaction().commit();
	
	}

	 /**
    * This method returns the list of all customers
    * @return customersList
    */
   @SuppressWarnings("unchecked")
   public List<Customer> getAllCustomers() throws Exception
   {
      List<Customer> customersList = new ArrayList<Customer>();
      Session session = sessionFactory.openSession();
      customersList = session.createQuery("from Customer").list();
      return customersList;
   }

   /**
    * This method updates the details of customer
    * @param customer
    */
   public void updateCustomerDetails(Customer customer) throws Exception
   {
      Session session = sessionFactory.openSession();
      session.beginTransaction();
      Customer updateCustomer =  (Customer)session.get(Customer.class, customer.getCustomerId()); 
      updateCustomer.setFirstName(customer.getFirstName());
      updateCustomer.setLastName(customer.getLastName());
      updateCustomer.setAddress(customer.getAddress());
      updateCustomer.setContactNum(customer.getContactNum());
      updateCustomer.setEmailId(customer.getEmailId());
      session.update(updateCustomer); 
      session.getTransaction().commit();
   }

   /**
    * This method gets the order details for logged in customer
    * @param customerId
    * @return orderDetails
    */
   public List<OrderDetails> getOrderDetails(String customerId) throws Exception
   {
      List<OrderDetails> orderDetails = new ArrayList<OrderDetails>();
      Session session = sessionFactory.openSession();
      Query query = session.createQuery("from OrderDetails where customerId= :customerId");
      query.setString("customerId", customerId);
      orderDetails = (List<OrderDetails>) query.list();
      return orderDetails;
   }

   /**
    * This method gets the order details of all the customers
    * @return orderDetails
    */
   public List<OrderDetails> getAllOrderDetails() throws Exception
   {
      List<OrderDetails> orderDetails = new ArrayList<OrderDetails>();
      Session session = sessionFactory.openSession();
      orderDetails = session.createQuery("from OrderDetails").list();
      return orderDetails;
   }

}
