package com.webshop.modelObjects;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;


/**
 * OrderDetails
 *
 * @author ahouji (c) Jun 11, 2015, Sogeti B.V.
 */ 
@Entity
@Table(name = "OrderDetails")
@SequenceGenerator(name = "ORDERSSEQUENCE", sequenceName = "ORDERSSEQUENCE", initialValue = 1, allocationSize = 1)
@Component(value = "orderDetails")
@Scope(value = "session")
public class OrderDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ORDERSSEQUENCE")
	@Column(name = "OrderDetailsId")
   private int orderDetailsId;
	
	@Column(name = "ORDERPLACEDID")
	private Date orderPlacedId;
	
	@Column(name = "CUSTOMERID")
	private int customerId;
	
	@Column(name = "CUSTOMERNAME")
   private String customerName;
	
	@Column(name = "SHIPPINGADDRESS")
   private String shippingAddress;
	
	@Column(name = "PRODUCTS")
	private String products;
	
	@Column(name = "TOTALPRICE")
   private int totalPrice;

	public int getTotalPrice()
   {
      return totalPrice;
   }

   public void setTotalPrice(int totalPrice)
   {
      this.totalPrice = totalPrice;
   }

   public String getCustomerName()
   {
      return customerName;
   }

   public void setCustomerName(String customerName)
   {
      this.customerName = customerName;
   }

	public String getShippingAddress()
   {
      return shippingAddress;
   }

   public void setShippingAddress(String shippingAddress)
   {
      this.shippingAddress = shippingAddress;
   }

   public int getOrderDetailsId()
   {
      return orderDetailsId;
   }

   public void setOrderDetailsId(int orderDetailsId)
   {
      this.orderDetailsId = orderDetailsId;
   }

   public Date getOrderPlacedId()
   {
      return orderPlacedId;
   }

   public void setOrderPlacedId(Date orderPlacedId)
   {
      this.orderPlacedId = orderPlacedId;
   }

   public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getProducts() {
		return products;
	}

	public void setProducts(String products) {
		this.products = products;
	}



}
