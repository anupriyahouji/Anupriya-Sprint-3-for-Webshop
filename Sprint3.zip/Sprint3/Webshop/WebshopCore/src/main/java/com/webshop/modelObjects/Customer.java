package com.webshop.modelObjects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;


/**
 * Customer
 *
 * @author ahouji (c) Jun 11, 2015, Sogeti B.V.
 */ 
@Entity
@Table(name = "CUSTOMER")
@SequenceGenerator(name = "customerSequence", sequenceName = "customerSequence", initialValue = 1, allocationSize = 1)
@Component(value = "customer")
@Scope(value = "session")

public class Customer
{

   @Id
   @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "customerSequence")
   @Column(name = "CUSTOMERID")
   private int customerId;
   
   @Column(name = "PASSWORD")
   private String password;
   
   @Column(name = "FIRSTNAME")
   private String firstName;
   
   @Column(name = "LASTNAME")
   private String lastName;
   
   @Column(name = "ADDRESS")
   private String address;
   
   @Column(name = "CONTACTNUM")
   private String contactNum;
   
   @Column(name = "EMAILID")
   private String emailId;
   
   @Column(name = "ROLEID")
   private int roleId;

   public int getCustomerId()
   {
      return customerId;
   }

   public void setCustomerId(int customerId)
   {
      this.customerId = customerId;
   }

   public String getPassword()
   {
      return password;
   }

   public void setPassword(String password)
   {
      this.password = password;
   }

   public String getFirstName()
   {
      return firstName;
   }

   public void setFirstName(String firstName)
   {
      this.firstName = firstName;
   }

   public String getLastName()
   {
      return lastName;
   }

   public void setLastName(String lastName)
   {
      this.lastName = lastName;
   }

   public String getAddress()
   {
      return address;
   }

   public void setAddress(String address)
   {
      this.address = address;
   }

   public String getContactNum()
   {
      return contactNum;
   }

   public void setContactNum(String contactNum)
   {
      this.contactNum = contactNum;
   }

   public String getEmailId()
   {
      return emailId;
   }

   public void setEmailId(String emailId)
   {
      this.emailId = emailId;
   }

   public int getRoleId()
   {
      return roleId;
   }

   public void setRoleId(int roleId)
   {
      this.roleId = roleId;
   }
}
