package com.webshop.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.webshop.dao.CustomerDao;
import com.webshop.modelObjects.Customer;
import com.webshop.modelObjects.OrderDetails;
import com.webshop.service.CustomerService;

/**
 * CustomerServiceImpl
 *
 * @author ahouji (c) Jun 11, 2015, Sogeti B.V.
 */ 
@Service("CustomerService")
public class CustomerServiceImpl implements CustomerService
{

   @Autowired
   CustomerDao customerDao;
   
   /**
    * This method registers the customer details and creates an account
    * @param customer
    */
   public void customerRegistration(Customer customer) throws Exception
   {
      customerDao.customerRegistration(customer);
   }

   /**
    * This method gets the customer details on login
    * @param userName
    * @param password
    */
   public Customer loginCustomer(String userName, String password) throws Exception
   {
      return customerDao.loginCustomer(userName,password);
   }

   /**
    * This method returns the list of all customers
    * @return customersList
    */
   public List<Customer> getAllCustomers() throws Exception
   {
      return customerDao.getAllCustomers();
   }

   /**
    * This method updates the details of customer
    * @param customer
    */
   public void updateCustomerDetails(Customer customer) throws Exception
   {
       customerDao.updateCustomerDetails(customer);
   }

   public List<OrderDetails> getOrderDetails(String customerId) throws Exception
   {
      return customerDao.getOrderDetails(customerId);
   }

   /**
    * This method gets the order details of all the customers
    * @return orderDetails
    */
   public List<OrderDetails> getAllOrderDetails() throws Exception
   {
      return customerDao.getAllOrderDetails();
   }

}
