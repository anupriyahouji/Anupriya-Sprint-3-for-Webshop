package com.webshop.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.webshop.dao.ProductsDao;
import com.webshop.modelObjects.OrderDetails;
import com.webshop.modelObjects.Product;
import com.webshop.service.ProductsService;

/**
 * ProductsServiceImpl
 *
 * @author ahouji (c) Jun 11, 2015, Sogeti B.V.
 */ 
@Service("ProductsService")
public class ProductsServiceImpl implements ProductsService{

	
	@Autowired
	ProductsDao productsDao;
	

   /**
    * This function returns all the product list  
    * @return productsList
    */
	public List<Product> getProductsList() throws Exception {
		
		return productsDao.getProductsList();
	}

	/**
    * This function saves the cart details and customer details in database
    * @param orderDetails
    */
	public void placedOrderDetails(OrderDetails orderDetails) throws Exception {
		
		 productsDao.placedOrderDetails(orderDetails);
	}

	 /**
    * This method updates the product details
    * @param product
    */
   public void updateProduct(Product product) throws Exception
   {
       productsDao.updateProduct(product);      
   }

   /**
    * This method deletes the product details
    * @param product
    */
   public void deleteProduct(Product product) throws Exception
   {
      productsDao.deleteProduct(product);      
   }

   /**
    * This method adds the new product details
    * @param product
    */
   public void addNewProduct(Product product) throws Exception
   {
      productsDao.addNewProduct(product);      
   }

}
