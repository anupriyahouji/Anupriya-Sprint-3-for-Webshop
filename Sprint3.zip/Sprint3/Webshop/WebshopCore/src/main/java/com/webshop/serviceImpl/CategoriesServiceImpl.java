package com.webshop.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.webshop.dao.CategoriesDao;
import com.webshop.modelObjects.Category;
import com.webshop.service.CategoriesService;

/**
 * CategoriesServiceImpl
 *
 * @author ahouji (c) Jun 12, 2015, Sogeti B.V.
 */ 
@Service("CategoriesService")
public class CategoriesServiceImpl implements CategoriesService
{

   @Autowired
   CategoriesDao categoriesDao;
   
   /**
    * This method returns the list of all categories
    * @return categoriesList
    */
   public List<Category> getCategoriesList() throws Exception
   {
      return categoriesDao.getCategoriesList();
   }

   /**
    * This method updates the category details
    * @param category
    */
   public void updateCategory(Category category) throws Exception
   {
      categoriesDao.updateCategory(category);
   }

   /**
    * This method adds the new category details
    * @param category
    */
   public void addNewCategory(Category category) throws Exception
   {
      categoriesDao.addNewCategory(category);
   }

   /**
    * This method deletes the category details
    * @param category
    */
   public void deleteCategory(Category category) throws Exception
   {
      categoriesDao.deleteCategory(category);
   }

}
