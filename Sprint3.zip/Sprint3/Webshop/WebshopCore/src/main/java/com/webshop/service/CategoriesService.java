package com.webshop.service;

import java.util.List;

import com.webshop.modelObjects.Category;

/**
 * CategoriesService
 *
 * @author ahouji (c) Jun 12, 2015, Sogeti B.V.
 */ 
public interface CategoriesService
{

   public List<Category> getCategoriesList() throws Exception;

   public void updateCategory(Category category) throws Exception;

   public void addNewCategory(Category category) throws Exception;

   public void deleteCategory(Category category) throws Exception;

}
