package com.webshop.daoImpl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.webshop.dao.CategoriesDao;
import com.webshop.modelObjects.Category;

/**
 * CategoriesDaoImpl
 *
 * @author ahouji (c) Jun 12, 2015, Sogeti B.V.
 */ 
@Repository("CategoriesDao")
public class CategoriesDaoImpl implements CategoriesDao
{

   @Autowired
   SessionFactory sessionFactory;
   
   /**
    * This method returns the list of all categories
    * @return categoriesList
    */
   @SuppressWarnings("unchecked")
   public List<Category> getCategoriesList() throws Exception
   {
      List<Category> categoriesList = new ArrayList<Category>();
      Session session = sessionFactory.openSession();
      categoriesList = session.createQuery("from Category").list();
      return categoriesList;
   }

   /**
    * This method updates the category details
    * @param category
    */
   public void updateCategory(Category category) throws Exception
   {
      Session session = sessionFactory.openSession();
      session.beginTransaction();
      Category updateCategory =  (Category)session.get(Category.class, category.getCategoryId()); 
      updateCategory.setCategoryName(category.getCategoryName());
      updateCategory.setCategoryDescription(category.getCategoryDescription());
      session.update(updateCategory); 
      session.getTransaction().commit();
            
   }

   /**
    * This method adds the new category details
    * @param category
    */
   public void addNewCategory(Category category) throws Exception
   {
      Session session = sessionFactory.openSession();
      session.beginTransaction();
      session.save(category);
      session.getTransaction().commit();
      
   }

   /**
    * This method deletes the category details
    * @param category
    */
   public void deleteCategory(Category category) throws Exception
   {
      Session session = sessionFactory.openSession();
      session.beginTransaction();
      Category cat = (Category) session.load(Category.class,category.getCategoryId());
      session.delete(cat);
      session.getTransaction().commit();
   }

}
