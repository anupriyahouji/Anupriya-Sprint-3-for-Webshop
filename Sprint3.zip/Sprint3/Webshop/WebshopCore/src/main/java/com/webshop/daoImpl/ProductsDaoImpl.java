package com.webshop.daoImpl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.webshop.dao.ProductsDao;
import com.webshop.modelObjects.Category;
import com.webshop.modelObjects.OrderDetails;
import com.webshop.modelObjects.Product;

/**
 * ProductDaoImpl
 *
 * 
 * @author ahouji (c) Jun 11, 2015, Sogeti B.V.
 */ 
@Repository("ProductsDao")
public class ProductsDaoImpl implements ProductsDao{

	@Autowired
	SessionFactory sessionFactory;
	
	/**
    * This function returns all the product list  
    * @return productsList
    */
	@SuppressWarnings("unchecked")
	public List<Product> getProductsList() throws Exception {
		
		List<Product> productsList = new ArrayList<Product>();
		Session session = sessionFactory.openSession();
		productsList = session.createQuery("from Product").list();
		return productsList;
	}

	/**
    * This function saves the cart details and customer details in database
    * @param orderDetails
    */
	public void placedOrderDetails(OrderDetails orderDetails) throws Exception {

		Session session = sessionFactory.openSession();
		session.beginTransaction();
		session.save(orderDetails);
		session.getTransaction().commit();
		
	}

	 /**
    * This method updates the product details
    * @param product
    */
   public void updateProduct(Product product) throws Exception
   {
      Session session = sessionFactory.openSession();
      session.beginTransaction();
      Product updateProduct =  (Product)session.get(Product.class, product.getProductId()); 
      updateProduct.setProductName(product.getProductName());
      updateProduct.setProductPrice(product.getProductPrice());
      updateProduct.setProductDescription(product.getProductDescription());
      session.update(updateProduct); 
      session.getTransaction().commit();
   }

   /**
    * This method deletes the product details
    * @param product
    */
   public void deleteProduct(Product product) throws Exception
   {
      Session session = sessionFactory.openSession();
      session.beginTransaction();
      Product prod = (Product) session.load(Product.class,product.getProductId());
      session.delete(prod);
      session.getTransaction().commit();
      
   }

   /**
    * This method adds the new product details
    * @param product
    */
   public void addNewProduct(Product product) throws Exception
   {
      Session session = sessionFactory.openSession();
      session.beginTransaction();
      session.save(product);
      session.getTransaction().commit();
      
   }

}
