package com.webshop.service;

import java.util.List;

import com.webshop.modelObjects.OrderDetails;
import com.webshop.modelObjects.Product;

/**
 * ProductsService
 *
 * @author ahouji (c) Jun 11, 2015, Sogeti B.V.
 */ 
public interface ProductsService {

	public List<Product> getProductsList() throws Exception;

	public void placedOrderDetails(OrderDetails orderDetails) throws Exception;

   public void updateProduct(Product product) throws Exception;

   public void deleteProduct(Product product) throws Exception;

   public void addNewProduct(Product product) throws Exception;

}
