




-- tables
-- Table: Category
CREATE TABLE Category (
    CategoryId int NOT NULL,
    CategoryName varchar2(20)  NOT NULL,
    CategoryDesc varchar2(30)  NOT NULL,
    CONSTRAINT Category_pk PRIMARY KEY (CategoryId)
) ;


CREATE TABLE Product (
    ProductId int NOT NULL,
    ProductName varchar2(20)  NOT NULL,
    ProductPrice number(5,2)  NOT NULL,
    ProductDesc varchar2(30)  NOT NULL,
    ProductStatus varchar2(10)  NOT NULL,
    CategoryId integer  NOT NULL,
    CONSTRAINT ProductId_pk PRIMARY KEY (ProductId)
) ;






-- Table: Order_Details

CREATE TABLE Order_Details (
    OrderDetailsId int NOT NULL,
    OrderId integer  NOT NULL,
    OrderDate timestamp  NOT NULL,
    ShippingAddress varchar2(30)  NOT NULL,
    ShippingCity varchar2(30)  NOT NULL,
    Pincode integer  NOT NULL,
    CustomerId integer  NOT NULL,
    OrderStatus varchar2(10)  NOT NULL,
    CONSTRAINT Order_Details_pk PRIMARY KEY (OrderDetailsId)
) ;




-- Table: Orders
CREATE TABLE Orders (
    Id integer  NOT NULL,
    OrderId int NOT NULL,
    ProductId integer  NOT NULL,
    Quantity integer  NOT NULL,
    Price number(5,2)  NOT NULL,
    CONSTRAINT Orders_pk PRIMARY KEY (Id)
) ;




-- Table: Role_Details
CREATE TABLE Role_Details (
    RoleId int NOT NULL,
    RoleName varchar2(10)  NOT NULL,
    CONSTRAINT Role_Details_pk PRIMARY KEY (RoleId)
) ;




-- Table: User_Details
CREATE TABLE Customer (
    CustomerId int NOT NULL,
    Password varchar2(10)  NOT NULL,
    FirstName varchar2(30)  NOT NULL,
    LastName varchar2(30)  NOT NULL,
    Address varchar2(50)  NOT NULL,
    Contactnum varchar2(15)  NOT NULL,
    EmailId varchar2(30)  NOT NULL,
    RoleId integer  NOT NULL,
    CONSTRAINT Customer_pk PRIMARY KEY (CustomerId)
) ;

--Table OrderDetails
CREATE TABLE OrderDetails
(
OrderDetailsId int NOT NULL,
CustomerId int NOT NULL,
CUSTOMERNAME varchar2(100),
SHIPPINGADDRESS varchar2(100),
TOTALPRICE int NOT NULL,
Products varchar2(355),
OrderPlacedId TIMESTAMP,
PRIMARY KEY (OrderDetailsId)
);




-- Sequence generators

--CREATE SEQUENCE CATEGORYSEQUENCE START WITH 1 INCREMENT BY   1;
--CREATE SEQUENCE CUSTOMERSEQUENCE START WITH 1 INCREMENT BY   1;
--CREATE SEQUENCE ORDERSSEQUENCE START WITH 1 INCREMENT BY   1;
--CREATE SEQUENCE PRODUCTSEQUENCE START WITH 1 INCREMENT BY   1;
--CREATE SEQUENCE ORDERDETAILS START WITH 1 INCREMENT BY   1;

   



-----insert scripts ---


---

-----For Category table

insert into CATEGORY values(1,'Food','All Food Products');
insert into CATEGORY values(2,'Medicines','All Medicinal Products');
insert into CATEGORY values(3,'Soap','All Soap Products');

--For Products table

insert into PRODUCT  values(1,'Pro Plan',250.00,'This makes your cat grow more','Active',1);
insert into PRODUCT  values(2,'Pedigree',200.00,'Healthy food for your dog','Active',1);
insert into PRODUCT  values(3,'Baby Pet',300.00,'Food for baby pets','Active',1);
insert into PRODUCT  values(4,'Drontal Puppy',150.00,'Medicine for your dog','Active',2);
insert into PRODUCT  values(5,'FrontLine Plus',350.00,'Medicine for your dog','Active',2);
insert into PRODUCT  values(6,'Hampl',400.00,'Medicine for your Cat','Active',2);
insert into PRODUCT  values(7,'Daisy',200.00,'Soap for your dog','Active',3);
insert into PRODUCT  values(8,'Crazy Cat',300.00,'Soap for your Cat','Active',3);
insert into PRODUCT  values(9,'Fido',300.00,'Soap for your pet','Active',3);


-----For Role details table

insert into ROLE_DETAILS values(1,'Customer');  
insert into ROLE_DETAILS values(0,'Admin');  

-- End of file.

